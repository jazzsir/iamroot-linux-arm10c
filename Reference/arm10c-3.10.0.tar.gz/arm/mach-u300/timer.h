extern void u300_timer_init(void);
