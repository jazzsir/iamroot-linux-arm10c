/*
 * arch/arm/mach-u300/include/mach/hardware.h
 */
#include <asm/sizes.h>
#include <mach/u300-regs.h>
