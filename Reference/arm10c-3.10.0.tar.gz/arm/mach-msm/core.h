extern struct smp_operations msm_smp_ops;
extern void msm_cpu_die(unsigned int cpu);
